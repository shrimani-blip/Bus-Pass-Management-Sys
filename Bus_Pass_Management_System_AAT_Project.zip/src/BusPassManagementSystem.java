import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.*;

/**
 * Bus Pass Management System - AAT Mini Project
 * Console-based Java application with CSV file storage.
 */
public class BusPassManagementSystem {
    private static final String DATA_FILE = "bus_passes.csv";
    private static final Scanner SC = new Scanner(System.in);
    private static final Map<Integer, BusPass> passes = new LinkedHashMap<>();
    private static int nextId = 1001;

    static class BusPass {
        int id;
        String name;
        String route;
        String passType;
        LocalDate issueDate;
        LocalDate expiryDate;
        double fee;
        String status;

        BusPass(int id, String name, String route, String passType,
                LocalDate issueDate, LocalDate expiryDate, double fee, String status) {
            this.id = id;
            this.name = name;
            this.route = route;
            this.passType = passType;
            this.issueDate = issueDate;
            this.expiryDate = expiryDate;
            this.fee = fee;
            this.status = status;
        }

        String toCsv() {
            return id + "," + clean(name) + "," + clean(route) + "," + clean(passType) + ","
                    + issueDate + "," + expiryDate + "," + fee + "," + status;
        }

        private static String clean(String value) {
            return value.replace(",", " ").trim();
        }

        static BusPass fromCsv(String line) {
            String[] p = line.split(",", -1);
            if (p.length != 8) return null;
            try {
                return new BusPass(Integer.parseInt(p[0]), p[1], p[2], p[3],
                        LocalDate.parse(p[4]), LocalDate.parse(p[5]),
                        Double.parseDouble(p[6]), p[7]);
            } catch (RuntimeException ex) {
                return null;
            }
        }
    }

    public static void main(String[] args) {
        loadData();
        System.out.println("======================================");
        System.out.println("       BUS PASS MANAGEMENT SYSTEM");
        System.out.println("======================================");
        while (true) {
            System.out.println("\\n1. Apply / Issue New Pass");
            System.out.println("2. View All Passes");
            System.out.println("3. Search Pass by ID");
            System.out.println("4. Renew Pass");
            System.out.println("5. Cancel Pass");
            System.out.println("6. Save and Exit");
            int choice = readInt("Enter your choice: ");
            switch (choice) {
                case 1: issuePass(); break;
                case 2: viewAll(); break;
                case 3: searchPass(); break;
                case 4: renewPass(); break;
                case 5: cancelPass(); break;
                case 6:
                    saveData();
                    System.out.println("Data saved. Thank you!");
                    SC.close();
                    return;
                default: System.out.println("Invalid choice. Select 1 to 6.");
            }
        }
    }

    private static void issuePass() {
        System.out.println("\\n--- New Bus Pass Application ---");
        String name = readNonEmpty("Passenger name: ");
        String route = readNonEmpty("Route (e.g., Tiruppur-Coimbatore): ");
        System.out.println("Pass types: 1. Student  2. General  3. Monthly");
        int typeChoice = readInt("Select pass type: ");
        String type;
        double fee;
        switch (typeChoice) {
            case 1: type = "Student"; fee = 300.00; break;
            case 2: type = "General"; fee = 600.00; break;
            case 3: type = "Monthly"; fee = 800.00; break;
            default:
                System.out.println("Invalid pass type. Application cancelled.");
                return;
        }

        LocalDate issue = LocalDate.now();
        LocalDate expiry = issue.plusMonths(1);
        BusPass pass = new BusPass(nextId++, name, route, type, issue, expiry, fee, "ACTIVE");
        passes.put(pass.id, pass);
        saveData();
        System.out.println("\\nPass issued successfully!");
        printPass(pass);
    }

    private static void viewAll() {
        System.out.println("\\n--- All Bus Passes ---");
        if (passes.isEmpty()) {
            System.out.println("No pass records found.");
            return;
        }
        System.out.printf("%-8s %-20s %-25s %-10s %-12s %-12s %-10s%n",
                "Pass ID", "Name", "Route", "Type", "Issue Date", "Expiry Date", "Status");
        for (BusPass p : passes.values()) {
            System.out.printf("%-8d %-20s %-25s %-10s %-12s %-12s %-10s%n",
                    p.id, shorten(p.name, 19), shorten(p.route, 24), p.passType,
                    p.issueDate, p.expiryDate, p.status);
        }
    }

    private static void searchPass() {
        int id = readInt("Enter pass ID: ");
        BusPass pass = passes.get(id);
        if (pass == null) {
            System.out.println("No pass found with ID " + id + ".");
        } else {
            printPass(pass);
        }
    }

    private static void renewPass() {
        int id = readInt("Enter pass ID to renew: ");
        BusPass pass = passes.get(id);
        if (pass == null) {
            System.out.println("Pass not found.");
            return;
        }
        if ("CANCELLED".equals(pass.status)) {
            System.out.println("Cancelled passes cannot be renewed.");
            return;
        }
        LocalDate today = LocalDate.now();
        LocalDate start = pass.expiryDate.isBefore(today) ? today : pass.expiryDate;
        pass.issueDate = today;
        pass.expiryDate = start.plusMonths(1);
        pass.status = "ACTIVE";
        saveData();
        System.out.println("Pass renewed successfully.");
        printPass(pass);
    }

    private static void cancelPass() {
        int id = readInt("Enter pass ID to cancel: ");
        BusPass pass = passes.get(id);
        if (pass == null) {
            System.out.println("Pass not found.");
            return;
        }
        if ("CANCELLED".equals(pass.status)) {
            System.out.println("Pass is already cancelled.");
            return;
        }
        pass.status = "CANCELLED";
        saveData();
        System.out.println("Pass cancelled successfully.");
    }

    private static void printPass(BusPass p) {
        System.out.println("--------------------------------------");
        System.out.println("              BUS PASS");
        System.out.println("--------------------------------------");
        System.out.println("Pass ID     : " + p.id);
        System.out.println("Name        : " + p.name);
        System.out.println("Route       : " + p.route);
        System.out.println("Pass Type   : " + p.passType);
        System.out.println("Issue Date  : " + p.issueDate);
        System.out.println("Expiry Date : " + p.expiryDate);
        System.out.printf("Fee         : Rs. %.2f%n", p.fee);
        System.out.println("Status      : " + p.status);
        System.out.println("--------------------------------------");
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = SC.nextLine().trim();
            try {
                return Integer.parseInt(value);
            } catch (NumberFormatException ex) {
                System.out.println("Please enter a valid whole number.");
            }
        }
    }

    private static String readNonEmpty(String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = SC.nextLine().trim();
            if (!value.isEmpty()) return value;
            System.out.println("This field cannot be empty.");
        }
    }

    private static String shorten(String value, int max) {
        return value.length() <= max ? value : value.substring(0, max - 3) + "...";
    }

    private static void loadData() {
        File file = new File(DATA_FILE);
        if (!file.exists()) return;
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                BusPass p = BusPass.fromCsv(line);
                if (p != null) {
                    passes.put(p.id, p);
                    nextId = Math.max(nextId, p.id + 1);
                }
            }
        } catch (IOException ex) {
            System.out.println("Warning: Could not load saved data: " + ex.getMessage());
        }
    }

    private static void saveData() {
        try (PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(DATA_FILE)))) {
            for (BusPass p : passes.values()) out.println(p.toCsv());
        } catch (IOException ex) {
            System.out.println("Error saving data: " + ex.getMessage());
        }
    }
}
