BUS PASS MANAGEMENT SYSTEM — AAT MINI PROJECT
================================================

Technology: Java (console application), CSV file storage
Requirements: JDK 8 or later

FILES
-----
src/BusPassManagementSystem.java : complete Java source code
Bus_Pass_Management_System_Report.docx : project documentation
Bus_Pass_Management_System_Presentation.pptx : presentation

HOW TO RUN
----------
1. Install a JDK (JDK 8 or later).
2. Open a terminal in the src folder.
3. Compile:
   javac BusPassManagementSystem.java
4. Run:
   java BusPassManagementSystem
5. The program creates/updates bus_passes.csv in the current working directory.

FEATURES
--------
- Issue a new pass with an automatically generated pass ID.
- List all pass records.
- Search for a pass by ID.
- Renew a pass for one month.
- Cancel a pass.
- Save and reload records using a CSV file.

DEMO NOTE
---------
Pass fees (Student Rs. 300, General Rs. 600, Monthly Rs. 800) are illustrative values
for the academic demo only. Change them to match the requirements of your institution
or transport provider. This is a mini-project demonstration, not a production payment system.
